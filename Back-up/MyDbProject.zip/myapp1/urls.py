from django.urls import include, path
from myapp1 import views
#from myapp1 import dashboardviews


#paths arranged alphabetically by name

app_name= 'myapp1'
urlpatterns= [
    #urls for student app

    path('index', views.MyIndexView.as_view(), name="student_index_view"),
    path('dashboard', views.DashboardView.as_view(), name="dashboard_view"),


]

