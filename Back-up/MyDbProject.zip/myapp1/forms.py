from django import forms
#from django.db.models import fields
from .models import *

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        model = Subject
        model = Course
        model = Registration
        fields= '__all__'
       

