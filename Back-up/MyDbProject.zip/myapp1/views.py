from django.shortcuts import render
from django.views.generic import View
from .forms import *


# Create your views here.

class MyIndexView(View):
    def get(self, request):
            return render(request,'index.html')

class DashboardView(View):
    def get(self, request):
        students = Student.objects.all()
        courses = Course.objects.all()
        subjects = Subject.objects.all()
        registration = Registration.objects.all()
        context = {
            'students' : students, 
            'courses' : courses,
            'subjects' : subjects,
            'registration' : registration
        }
        return render(request,'dashboard.html', context)
